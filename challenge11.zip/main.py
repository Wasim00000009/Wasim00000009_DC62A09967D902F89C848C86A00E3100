year=int(input("enter the year:"))
if(year%4==0):
  print(year,"is leaf year")
else:
  print(year,"non leaf year")